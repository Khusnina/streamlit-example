# Text-summarizer
# How to run

1 install the libraries which is given in requirements.txt folder

2 open your cmd

3 Run a command : streamlit run app.py
